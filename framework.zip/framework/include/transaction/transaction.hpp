/*
 * transaction.hpp
 *
 *  Created on: 2014��11��10��
 *      Author: akumas
 */

#ifndef INCLUDE_TRANSACTION_TRANSACTION_HPP_
#define INCLUDE_TRANSACTION_TRANSACTION_HPP_


#include <transaction/base_manager.hpp>

#endif /* INCLUDE_TRANSACTION_TRANSACTION_HPP_ */
