#!/usr/bin/python
##__all__ = ["load_config", "query_node", "control_trans_manager",
##           "query_rack", "query_room", "task_type", "task_session",
##           "add_server_room", "remove_server_room",
##           "add_computer_rack", "remove_computer_rack",
##           "query_disk_image","query_domain",
##           "create_guest_domain", "delete_guest_domain",
##           "start_guest_domain", "stop_guest_domain",
##           "add_node", "remove_node"]


